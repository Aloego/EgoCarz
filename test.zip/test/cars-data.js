// js/cars-data.js
const carData = [

        {
          id: "car1",
          name: "Toyota Camry 2020",
          images: [
            "images/carPhotos.jpg",
            "images/carPhotos2.jpg",
            "images/CarPhoto3.jpg",
            "images/CarPhoto4.jpg",
          ],
          year: "2020",
          price: "₦4,000,000",
          mileage: "45,000km",
          location: "Lagos",
          description: "This Toyota Camry 2020 is in excellent condition with a clean interior and exterior. Perfect for city and highway driving."
        },

        {
          id: "car2",
          name: "Honda CR-V 2019",
          images: [
            "images/carWhite.jpg",
            "images/carWhite2.jpg"
          ],
          price: "₦5,500,000",
          mileage: "35,000km",
          location: "Abuja",
          description: "A well-maintained Honda CR-V with great fuel efficiency and advanced safety features. Smooth and reliable."
        },

        {
            id: "car1",
            name: "Toyota Camry 2020",
            image: "images/carPhotos.jpg",
            price: "₦4,000,000",
            mileage: "45,000km",
            location: "Lagos",
            description: "This Toyota Camry 2020 is in excellent condition with a clean interior and exterior. Perfect for city and highway driving."
          },

          {
            id: "car2",
            name: "Honda CR-V 2019",
            image: "images/carWhite.jpg",
            price: "₦5,500,000",
            mileage: "35,000km",
            location: "Abuja",
            description: "A well-maintained Honda CR-V with great fuel efficiency and advanced safety features. Smooth and reliable."
          }
          
          // Add more cars here
      
  ];
  